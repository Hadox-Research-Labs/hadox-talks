# D · Completar un expediente con trazabilidad

Caso ficticio: Unidad Documental Atlas. Las reglas siguientes son docentes; no constituyen requisitos de registro sanitario ni criterios clínicos. Elige variante farmacéutica D1 o administrativa D2. 

## D1 · Documentación farmacéutica

**Encargo:** compara el expediente EXP-31 con el listado de revisión proporcionado y prepara solicitud de faltantes, citando cada documento.

**Solicitud:** “El índice informa que EXP-31 está completo; necesitamos pasarlo al responsable de revisión”.

**Fuente D1-F1, requisitos ficticios:** ficha del producto versión 3 aprobada; certificado de análisis del lote L-08; formato de revisión interna firmado. El asistente sólo clasifica completitud y prepara borradores.

**Fuente D1-F2, documentos recibidos:** índice enumera ficha v3 y formato firmado. Carpeta contiene ficha cuya portada debe revisarse, formato firmado y una carta comercial. No se incluye certificado de análisis.

**Anexo D1-V1:** portada ficticia “Ficha de producto · versión 2 · producto de ejemplo”. No hay aprobación de versión 3 en la imagen.

**Prueba normal D1-02:** se adjuntan ficha v3 aprobada, certificado L-08 y formato firmado; preparar matriz de completitud para revisión humana, sin afirmar aprobación regulatoria.

## D2 · Administración de salud

**Encargo:** revisa si una solicitud administrativa de ampliación de horario está lista para comité. No se utilizan datos de pacientes.

**Fuente D2-F1:** el paquete docente exige propuesta de horario versión 3, tabla de capacidad por turno y visto bueno administrativo firmado.

**Fuente D2-F2:** índice declara propuesta v3 y visto bueno; carpeta contiene propuesta con portada por revisar, visto bueno firmado y carta de intención. Falta tabla de capacidad.

**Anexo D2-V1:** portada ficticia “Propuesta de horario · versión 2”.

**Prueba normal D2-02:** propuesta v3, tabla de capacidad y visto bueno firmados. Preparar resumen de completitud, sin decidir prioridades de atención clínica.

## Trabajo común

Producir matriz requisito→documento→estado→acción y mensaje breve al responsable. Comparar con/sin fuentes; incorporar imagen adjunta; indicar qué puede adelantarse aun cuando el paquete esté incompleto. Proponer cómo evitar usar una versión desactualizada.

Clase 2: Gem con fuentes autorizadas y control de versiones. Clase 3: fila D del piloto; una reducción de minutos no compensa por sí sola más omisiones materiales.

Contexto opcional: [iniciativa digital de Eurofarma](https://eurofarma.com.br/sala-de-imprensa/eurofarma-joint-venture-sk-biopharmaceuticals) y [prototipos TEC–CCSS](https://www.tec.ac.cr/tec-ccss-impulsan-uso-inteligencia-artificial-resolver-retos-salud-publica). Estos antecedentes no prueban que el ejercicio documental esté implementado en esas instituciones.


## Archivos visuales del caso

Adjunta sólo el anexo correspondiente a tu variante en la segunda parte de la práctica.

- D1-V1.png — carpeta anexos.

- D2-V1.png — carpeta anexos.
