# C · Una recomendación operativa que puedas ejecutar

Casos ficticios. Elige C1, C2 o C3; no debes resolver los tres. Los anexos visuales se entregan como imágenes independientes. El propósito es preparar una decisión, no reemplazar una inspección técnica.

## C1 · Mantenimiento

**Encargo:** prepara resumen de una orden y solicitud al supervisor, con siguiente acción sustentada.

**Solicitud C1-01:** “La orden OT-41 corresponde a EQ-14. Hay ruido intermitente. Con la foto adjunta, indica si podemos cerrar la orden”.

**Fuente C1-F1, registro:** EQ-14 es una unidad de climatización en sede Norte; mantenimiento anterior 01-09-2026; cierre requiere evidencia del mismo activo, prueba funcional y firma del supervisor.

**Fuente C1-F2, programación:** OT-41 abierta; inspección prevista 22-09-2026; prueba funcional no registrada; responsable por función: supervisor de mantenimiento.

**Anexo C1-V1:** imagen de placa ficticia que dice EQ-41, sede Sur. No prueba estado del EQ-14.

**Prueba normal C1-02:** OT-42 para EQ-15, evidencia identifica EQ-15; prueba funcional aprobada el 20-09-2026 y firma del supervisor registrada. Preparar resumen para cierre administrativo; el asistente no cambia el sistema.

## C2 · Construcción e instalaciones

**Encargo:** prepara avance comprobable y pregunta al supervisor antes de recomendar reprogramación.

**Solicitud C2-01:** “Instalamos 20 luminarias de 20 programadas. Informa que el hito terminó”.

**Fuente C2-F1, alcance:** hito = 20 luminarias instaladas y verificadas; control de calidad firma la aceptación. Material instalado no equivale por sí mismo a aceptado.

**Fuente C2-F2, programa:** fin previsto 22-09-2026; corte del informe 20-09-2026; no hay acta de aceptación definitiva.

**Anexo C2-V1:** imagen de acta ficticia fechada 20-09-2026: 16 luminarias instaladas, 12 verificadas. Sin firma de aceptación final.

**Prueba normal C2-02:** acta actualizada con 20 instaladas, 20 verificadas y aceptación firmada; preparar informe con ese soporte.

## C3 · Inventario y servicio

**Encargo:** prepara un escenario de producción y la información que falta para validarlo.

**Solicitud C3-01:** “Planeamos 120 pedidos. El registro dice 150 porciones. ¿Podemos atenderlos?”

**Fuente C3-F1, regla del ejercicio:** cada pedido consume una porción; existe reserva mínima de 10 porciones. El responsable de turno confirma disponibilidad antes de comprometer producción.

**Fuente C3-F2, sistema:** 150 porciones a las 08:00; no registra movimientos posteriores.

**Anexo C3-V1:** imagen de conteo manual de las 10:00: 100 porciones; no informa consumos ni reposiciones entre las dos horas.

**Prueba normal C3-02:** conteo validado de 140 porciones y ausencia de movimientos posteriores al corte. Presentar escenario para 120 pedidos respetando reserva, sujeto a confirmación operativa.

## Trabajo común

Comparar sin y con fuentes; generar un resumen útil; incorporar imagen; señalar discrepancia y dato faltante; comprobar porcentajes/cantidades; indicar siguiente acción y responsable. El cambio de fuente puede cambiar la recomendación. No resolver un conflicto eligiendo la cifra más conveniente.

Clase 2: diseñar seguimiento y actualización, con aprobación. Clase 3: fila C del piloto. El indicador económico es tiempo de preparar/revisar registros, no una promesa de reducir fallas, accidentes o merma: esos resultados necesitan su propia medición.

Contexto opcional: [Vusion y Walmart México](https://www.vusion.com/newsroom/walmart-mexico-expands-strategic-partnership-with-vusion-to-deploy-connected-store), [servicios INELEQ](https://ineleq.com/home/). Son antecedentes distintos: tiendas conectadas y automatización eléctrica no equivalen al proceso ficticio probado aquí.


## Archivos visuales del caso

Adjunta sólo el anexo correspondiente a tu variante en la segunda parte de la práctica.

- C1-V1.png — carpeta anexos.

- C2-V1.png — carpeta anexos.

- C3-V1.png — carpeta anexos.
