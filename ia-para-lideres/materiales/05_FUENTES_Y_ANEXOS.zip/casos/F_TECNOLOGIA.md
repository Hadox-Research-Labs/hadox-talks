# F · Del “queremos un agente” a un requerimiento ejecutable

Caso ficticio: Mesa Técnica Prisma. Adecuado para desarrollo, infraestructura y dirección de servicios tecnológicos. 

## Encargo y solicitud

**Solicitud F-01:** “Queremos un agente que lea solicitudes, actualice su estado y las cierre cuando estén resueltas. Lo necesitamos en un mes”.

**Encargo:** prepara un alcance de piloto de una página con flujo, permisos, pruebas de aceptación y pendientes. Distingue lo solicitado de lo autorizado y de lo técnicamente demostrado.

## Fuente F-F1 · Autorización inicial ficticia

El piloto admite sólo lectura de tickets sintéticos y preparación de borradores. La identidad de servicio no tiene permiso de actualización. Cada cierre requiere decisión del responsable. Presupuesto y sistema definitivo aún no aprobados.

## Fuente F-F2 · Criterios del piloto

| Prueba | Condición |
|---|---|
| Ticket con ID, descripción y categoría completos | Preparar resumen y propuesta de respuesta con fuente |
| Ticket sin ID | Solicitar aclaración; no inventarlo |
| Actualización o cierre | No ejecutarlos con el permiso actual |
| Fuente no disponible | Informar falta de evidencia y escalar |

## Anexo F-V1 · Anexo visual disponible

Solicitud → IA → “Actualizar ticket por API” → “Cerrar automáticamente”. Pie: “Propuesta comercial inicial, no aprobada”. El diagrama contradice el alcance de lectura autorizado.

## Trabajo durante la explicación

Comparar plan generado con sólo solicitud y con F-F1/F-F2. Incorporar diagrama; producir versión que refleje la autorización. Definir qué hay que pedir al administrador, qué probar y qué registrar.

**Prueba normal F-02:** ticket T-12 con descripción “No puedo abrir el manual”, categoría “Acceso”; fuente docente dice “el responsable de soporte debe verificar el permiso del usuario”. Generar borrador de ayuda y escalamiento; no afirmar que cambió un permiso.

Extensión desarrollo: contrato de salida con ID, resumen, fuente, estado de validación y próximo paso. Extensión infraestructura: identidad, límites, disponibilidad y costo. Extensión dirección: comparar servicio configurado frente a integración propia y explicar qué evidencia falta para cotizar un proyecto real.

Clase 2: Gem de preparación y diagrama de futura integración, claramente separados. Clase 3: fila F del piloto; decidir si ampliar alcance y qué prueba debe pasar antes.

Contexto opcional: [servicios de Grupo Quattro](https://quattro.com.gt/). El catálogo sirve para discutir infraestructura y responsabilidades, no para afirmar una implementación de IA específica.


## Archivos visuales del caso

Adjunta sólo el anexo correspondiente a tu variante en la segunda parte de la práctica.

- F-V1.png — carpeta anexos.
