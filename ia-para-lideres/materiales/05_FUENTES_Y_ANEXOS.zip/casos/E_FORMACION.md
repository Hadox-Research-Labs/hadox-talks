# E · Una guía que cambie la práctica

Caso ficticio: Equipo Aprender. Aplicable a inducción, docencia y adopción de un proceso. 

## Encargo y solicitud

**Encargo:** transforma el procedimiento en una guía de cinco pasos y dos preguntas para comprobar que alguien sabe aplicarlo. Debe poder utilizarse en una explicación de cinco minutos.

**Solicitud E-01:** “Tenemos muchas dudas repetidas. Simplifica el procedimiento y prepara una guía para los nuevos integrantes”.

## Fuente E-F1 · Procedimiento autorizado v2

1. Recibir solicitud y verificar los tres campos: objetivo, destinatario y fecha.
2. Preparar borrador y relacionar cada afirmación factual con su fuente.
3. Solicitar revisión al responsable de contenido.
4. Publicar sólo después de aceptación explícita.
5. Registrar versión y fecha de publicación.

## Fuente E-F2 · Dos situaciones de práctica

| Situación | Datos |
|---|---|
| E-01 | Borrador completo, sin aceptación del responsable |
| E-02 | Borrador con fuentes, aceptación registrada y tres campos completos |

## Anexo E-V1 · Anexo visual disponible

Infografía de un borrador antiguo: “1. Recibe; 2. Redacta; 3. Publica; 4. Avisa al responsable; 5. Archiva”. Identificación visible: borrador v1. Sello “FICTICIO”.

## Trabajo durante la explicación

Comparar guía generada sin procedimiento y con E-F1. Probar que las dos preguntas distinguen E-01 y E-02. Incorporar la infografía y revisar si el asistente detecta el conflicto de secuencia. Entregar guía corregida y una forma de observar su aplicación.

Para docencia: redactar retroalimentación sobre una respuesta ficticia que dice “puedo publicar y avisar después”; justificar contra E-F1 sin atribuir intención a la persona. Para transformación: definir indicador de consultas repetidas y retrabajo. El caso evalúa la calidad de una guía; no determina automáticamente la calificación de un alumno real.

Clase 2: configurar generación/revisión/publicación y quién mantiene el procedimiento. Clase 3: fila E del piloto; distinguir producir contenido más rápido de aprender o adoptar mejor.

Lectura opcional: [formación docente USAC](https://virtual.usac.edu.gt/dda/sfpu-cursos/). Identificar qué práctica docente valdría la pena evaluar y cómo comprobarla.


## Archivos visuales del caso

Adjunta sólo el anexo correspondiente a tu variante en la segunda parte de la práctica.

- E-V1.png — carpeta anexos.
