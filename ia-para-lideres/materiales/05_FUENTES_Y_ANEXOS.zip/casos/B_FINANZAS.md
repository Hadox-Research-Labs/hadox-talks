# B · Conciliar antes de autorizar

Caso ficticio: Servicios Delta. Importes sin impuestos ni descuentos para aislar la comprobación. Material de trabajo.

## Encargo y solicitud

El equipo recibe facturas por correo y busca reducir el tiempo de preparación de la revisión. **Encargo:** prepara una conciliación de factura contra recepción y un borrador de mensaje al responsable de compras para resolver excepciones. No autorices ni ejecutes pagos.

**Solicitud B-01:** “La factura FAC-101 contiene 10 filtros a Q120 cada uno. Total Q1,200. Prepárala para revisión de pago”.

## Fuente B-F1 · Recepciones registradas

| Factura | Artículo | Unidades recibidas | Precio unitario pactado |
|---|---|---:|---:|
| FAC-101 | Filtro T10 | 8 | Q120 |
| FAC-102 | Filtro T10 | 5 | Q120 |

## Fuente B-F2 · Política ficticia

Sólo una coincidencia de factura, recepción y precio puede pasar como “sin excepción” a revisión del responsable. Las diferencias se listan con importe y soporte pendiente. Se permite preparar conciliación y borrador; el responsable decide tratamiento contable y pago. No presumir fraude, devolución o entrega pendiente sin evidencia.

## Anexo B-V1 · Anexo visual disponible

Factura ficticia FAC-101, emitida por Proveedor de Ejemplo, artículo Filtro T10, **10 unidades, Q120, Q1,200**. Sello “USO DOCENTE”. La imagen confirma la factura; la contradicción se encuentra al cruzarla con recepción.

## Trabajo durante la explicación

1. Comparar respuesta con sólo solicitud frente a solicitud+B-F1+B-F2.
2. Preparar tabla facturado/recibido/diferencia y comprobar cada operación con calculadora.
3. Agregar B-V1 como imagen adjunta; indicar qué confirma y qué no explica.
4. Redactar un mensaje de hasta 80 palabras que permita al responsable resolver la diferencia.

**Prueba normal B-02:** FAC-102 factura 5 filtros a Q120, total Q600. Debe poder preparar una revisión sin excepción con las fuentes disponibles, sin convertirse en autorización de pago.

Extensión de tesorería: saldo inicial Q10,000; cobro confirmado Q4,000; pago independiente autorizado Q3,000; FAC-101 permanece pendiente. Presenta saldo previsto sin incluir FAC-101 y un escenario si finalmente se paga completa. No tratar un escenario como pago aprobado.

Extensión de contraloría: definir qué evidencia distingue una diferencia documental de un incumplimiento demostrado.

## Continuidad

Clase 2: configurar asistente que clasifique y prepare; identificar quién aprueba y qué registro queda. Clase 3: fila B del piloto, distinguiendo capacidad liberada, gasto y dinero disponible.

Contexto opcional: [MultiMoney y HubSpot](https://www.hubspot.es/case-studies/multimoney). Describe uso en la organización; no documenta este proceso contable ficticio.


## Archivos visuales del caso

Adjunta sólo el anexo correspondiente a tu variante en la segunda parte de la práctica.

- B-V1.png — carpeta anexos.
