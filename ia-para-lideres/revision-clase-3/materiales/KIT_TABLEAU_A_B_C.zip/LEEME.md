# Kit Tableau · A, B y C

Todo el contenido de `demo_ficticia/` es ficticio, incluidos perfiles, afirmaciones, fuentes, fechas y costos. No representa resultados del grupo ni hechos de una empresa real. Se usa para ensayar el modelo, los cálculos y la demostración. No mezclar estas filas con las entregas reales.

`plantillas_vacias/` conserva las cabeceras para preparar una síntesis revisada de las entregas. El profesor propone la preparación; cada autor comprueba los campos. Conservar identificadores, origen, fechas que realmente consten y acceso apropiado. Una fecha de corte no reemplaza la fecha del evento.

Hay seis tablas. Mantener niveles de detalle y relacionar identificadores; no unir todas las tablas de forma que se multipliquen costos o requisitos. Recomendaciones B se relaciona con Personas B por propietario y, cuando corresponde, otra instancia por compañero. Encaje C enlaza requisitos de la oportunidad con un candidato o conserva persona vacía para una brecha. Un enlace Encaje–Recomendaciones es opcional y requiere comprobar salida y versión.

Comprobaciones del ejemplo: 3 oportunidades; A01 tiene 2 afirmaciones HECHO distintas, 1 comprobada (50%); sus 3 requisitos tienen 2 con candidato documentado y encaje SI (66,67% potencial). Hay 4 salidas históricas: 3 recomendaciones y 1 abstención. Ninguna registra acuerdos. A03 no tiene afirmaciones HECHO y su cobertura queda nula.

Escenarios ficticios A01: software existente, USD 420/mes y USD 2 260 a 3 meses; solución especializada, USD 516/mes y USD 4 048; integración propia, USD 630/mes y USD 5 890. Costo mensual = tecnología + horas × costo/h; TCO = inicial + meses × mensual. No hay beneficio cuantificado ni cálculo de ROI. Estas cifras son distintas del ejercicio de 10 000 casos de la clase.

Fuentes y disponibilidad: ver GUION_TABLEAU_ENSAYO.md. La demostración de IA requiere una cuenta compatible. El kit no crea ni habilita una cuenta ni un dashboard de Cloud.
