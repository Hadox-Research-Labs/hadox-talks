# Kit de clase 2 · 27 septiembre 2026

Empieza por PREPARACION_CLASE_2.md. Después abre GUIA_2.md y las dos guías de demostración.
Los cinco PDF PERFIL_* son entradas ficticias: cuatro personas y una actualización de BRUNO.
DIRECTORIO_REVISION_DOCENTE.md es una referencia elaborada para revisar el ensayo, no una ejecución de IA.
INVESTIGACION_INTERLOCUTOR.md debe completarse con tu investigación de clase 1 antes de generar una propuesta sustentada.
La instalación, conexiones y ejecuciones en cuentas requieren ensayo. Este kit no contiene credenciales ni un blueprint probado.
La actividad B y la dinámica de grupo están en sus documentos. Las entregas y fechas formales las comunica PBS.
